import React from 'react';
import { StyleSheet, View, Image, Text } from 'react-native';
import { Card, Badge } from 'react-native-paper';

import CustomBadge from '../CustomBadge/CustomBadge';

type CategoryCardProps = {
  title: string;
  count: number;
  images: string[];
  onPress?: () => void;
};

const CategoryCard: React.FC<CategoryCardProps> = ({ title, count, images, onPress }) => {
  return (
    <Card style={styles.card} onPress={onPress}>
      <View style={styles.imageContainer}>
        {images.map((image, index) => (
          <Image key={index} source={{ uri: image }} style={styles.image} />
        ))}
      </View>
      <View style={styles.footer}>
        <Text style={styles.title}>{title}</Text>
        <CustomBadge text={count.toString()} />
      </View>
    </Card>
  );
};

const styles = StyleSheet.create({
  // card styles
  card: {
    borderRadius: 9,
    backgroundColor: '#fff',
    padding: 7,
  },
  imageContainer: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    flexWrap: 'wrap',
    gap: 5,
  },
  image: {
    width: '45%',
    height: 70,
    borderRadius: 9,
  },
  // footer styles
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  badge: {
    backgroundColor: '#753742',
    color: '#fff',
    fontSize: 14,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 20,
  },
});

export default CategoryCard;
