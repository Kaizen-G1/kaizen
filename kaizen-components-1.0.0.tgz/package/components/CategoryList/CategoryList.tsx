import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';

// Component
import CustomIcon from '../CustomIcon/CustomIcon';
import CategoryCard from '../CategoryCard/CategoryCard';

type CategoryListProps = {
  title: string;
  categories: {
    id: string;
    title: string;
    count: number;
    images: string[];
  }[];
  onSelectCategory: (id: string) => void;
  onSeeAll: () => void;
  maxVisibleCategories?: number;
};

const CategoryList: React.FC<CategoryListProps> = ({ 
  title, 
  categories, 
  onSelectCategory,
  onSeeAll,
  maxVisibleCategories = 4 }) => {
  const visibleCategories = categories.slice(0, maxVisibleCategories);

  return (
    <>
      {/* title section */}
      <View style={styles.header}>
        <Text style={styles.title}>{title}</Text>
        {categories.length > maxVisibleCategories && (
          <TouchableOpacity onPress={onSeeAll} style={styles.seeAllContainer}>
            <Text style={styles.seeAllText}>See All</Text>
            <CustomIcon icon='arrow-right' type='circle'/>
          </TouchableOpacity>
        )}
      </View>
      {/* list section */}
      <View style={styles.grid}>
        {visibleCategories.map((item) => (
          <View key={item.id} style={styles.cardContainer}>
            <CategoryCard
              title={item.title}
              count={item.count}
              images={item.images}
              onPress={() => onSelectCategory(item.id)}
            />
          </View>
        ))}
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  seeAllContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  seeAllText: {
    fontSize: 15,
    fontWeight: 'bold',
  },
  grid: {
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-evenly',
  },
  cardContainer: {
    marginBottom: 5,
    width: '48%',
  },
});

export default CategoryList;
