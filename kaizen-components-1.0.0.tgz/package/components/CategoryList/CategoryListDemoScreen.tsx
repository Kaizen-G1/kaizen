import React from 'react'
import { StyleSheet, View, Text } from 'react-native'

// Component
import CategoryList from './CategoryList'

// Mock Data
const CATEGORIES_ITEMS = [
  {
    id: "100",
    title: 'Clothing',
    count: 109,
    images: [
      'https://www.fastrack.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwc964554d/images/Fastrack/Catalog/38077AP02_1.jpg?sw=600&sh=600',
      'https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Apple_Watch_Series_8_Midnight_Aluminium_Case.jpg/1200px-Apple_Watch_Series_8_Midnight_Aluminium_Case.jpg',
      'https://www.sonatawatches.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwc041fffc/images/Sonata/Catalog/SP80062KM01W_1.jpg?sw=600&sh=600',
      'https://www.apple.com/v/watch/bo/images/overview/consider_modals/fitness/modal_fitness_rings__cznvg9yafq82_xlarge.jpg',
    ],
  },
  {
    id: "200",
    title: 'Shoes',
    count: 530,
    images: [
      'https://www.fastrack.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwc964554d/images/Fastrack/Catalog/38077AP02_1.jpg?sw=600&sh=600',
      'https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Apple_Watch_Series_8_Midnight_Aluminium_Case.jpg/1200px-Apple_Watch_Series_8_Midnight_Aluminium_Case.jpg',
      'https://www.sonatawatches.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwc041fffc/images/Sonata/Catalog/SP80062KM01W_1.jpg?sw=600&sh=600',
      'https://www.apple.com/v/watch/bo/images/overview/consider_modals/fitness/modal_fitness_rings__cznvg9yafq82_xlarge.jpg',
    ],
  },
  {
    id: "300",
    title: 'Bags',
    count: 87,
    images: [
      'https://www.fastrack.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwc964554d/images/Fastrack/Catalog/38077AP02_1.jpg?sw=600&sh=600',
      'https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Apple_Watch_Series_8_Midnight_Aluminium_Case.jpg/1200px-Apple_Watch_Series_8_Midnight_Aluminium_Case.jpg',
      'https://www.sonatawatches.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwc041fffc/images/Sonata/Catalog/SP80062KM01W_1.jpg?sw=600&sh=600',
      'https://www.apple.com/v/watch/bo/images/overview/consider_modals/fitness/modal_fitness_rings__cznvg9yafq82_xlarge.jpg',
    ],
  },
  {
    id: "400",
    title: 'Shoes',
    count: 530,
    images: [
      'https://www.fastrack.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwc964554d/images/Fastrack/Catalog/38077AP02_1.jpg?sw=600&sh=600',
      'https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Apple_Watch_Series_8_Midnight_Aluminium_Case.jpg/1200px-Apple_Watch_Series_8_Midnight_Aluminium_Case.jpg',
      'https://www.sonatawatches.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwc041fffc/images/Sonata/Catalog/SP80062KM01W_1.jpg?sw=600&sh=600',
      'https://www.apple.com/v/watch/bo/images/overview/consider_modals/fitness/modal_fitness_rings__cznvg9yafq82_xlarge.jpg',
    ],
  },
  {
    id: "500",
    title: 'Bags',
    count: 87,
    images: [
      'https://www.fastrack.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwc964554d/images/Fastrack/Catalog/38077AP02_1.jpg?sw=600&sh=600',
      'https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Apple_Watch_Series_8_Midnight_Aluminium_Case.jpg/1200px-Apple_Watch_Series_8_Midnight_Aluminium_Case.jpg',
      'https://www.sonatawatches.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwc041fffc/images/Sonata/Catalog/SP80062KM01W_1.jpg?sw=600&sh=600',
      'https://www.apple.com/v/watch/bo/images/overview/consider_modals/fitness/modal_fitness_rings__cznvg9yafq82_xlarge.jpg',
    ],
  }
];

export const CategoryListDemoScreen = () => {

  const handleSelectCategory = (id: string) => {
    console.log(`Selected category ID: ${id}`);
  };

  const handleSeeAllCategories = () => {
    console.log(`See all categories`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>CategoryListDemoScreen</Text>
      <CategoryList
        title="Categories"
        categories={CATEGORIES_ITEMS}
        onSelectCategory={handleSelectCategory}
        onSeeAll={handleSeeAllCategories}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 20,
    marginBottom: 15,
  },
  title: {
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 18,
    marginBottom: 10,
    color: 'red',
  }
});
