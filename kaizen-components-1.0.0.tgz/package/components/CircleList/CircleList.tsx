import React from 'react';
import { StyleSheet, ScrollView, Text } from 'react-native';

// Components
import CircleItem from '../CircleItem/CircleItem';

type CircleListProps = {
  title: string;
  items: { id: string; image: string; label: string }[];
  onPress: (label: string) => void;
};

const CircleList: React.FC<CircleListProps> = ({ title, items, onPress }) => {
  return (
    <>
      <Text style={styles.title}>{title}</Text>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContainer}
      >
        {items.map((item) => (
          <CircleItem
            key={item.id}
            image={item.image}
            onPress={() => onPress(item.label)}
          />
        ))}
      </ScrollView>
    </>
  );
};

const styles = StyleSheet.create({
  title: {
    fontSize: 21,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  scrollContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
  },
});

export default CircleList;
