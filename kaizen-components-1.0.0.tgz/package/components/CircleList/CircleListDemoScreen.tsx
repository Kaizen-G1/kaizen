import React from 'react'
import { StyleSheet, View, Text } from 'react-native'

// Component
import CircleList from './CircleList';

// Mock Data
const CIRCLE_LIST_ITEMS = [
  { id: "100", image: 'https://www.fastrack.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwc964554d/images/Fastrack/Catalog/38077AP02_1.jpg?sw=600&sh=600', label: 'Item 1' },
  { id: "200", image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Apple_Watch_Series_8_Midnight_Aluminium_Case.jpg/1200px-Apple_Watch_Series_8_Midnight_Aluminium_Case.jpg', label: 'Item 2' },
  { id: "300", image: 'https://www.sonatawatches.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwc041fffc/images/Sonata/Catalog/SP80062KM01W_1.jpg?sw=600&sh=600', label: 'Item 3' },
  { id: "400", image: 'https://www.apple.com/v/watch/bo/images/overview/consider_modals/fitness/modal_fitness_rings__cznvg9yafq82_xlarge.jpg', label: 'Item 4' },
  { id: "500", image: 'https://images.samsung.com/is/image/samsung/assets/us/2407/watches/Watches-PCD_CO15_Sleep-Coaching_MO.jpg?$624_624_JPG$', label: 'Item 5' },
];

export const CircleListDemoScreen = () => {

  const handlePress = (label: string) => {
    console.log(`Pressed: ${label}`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>CircleListDemoScreen</Text>
      <CircleList title='Circle List' items={CIRCLE_LIST_ITEMS} onPress={handlePress} />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 20,
    marginBottom: 15,
  },
  title: {
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 18,
    marginBottom: 10,
    color: 'red',
  }
});

export default CircleList;
