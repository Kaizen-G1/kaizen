import React, { useState } from 'react';
import { StyleSheet, View, Text } from 'react-native';

// Component
import CustomButton from './CustomButton';

export const CustomButtonDemoScreen = () => {

  const [isLoading, setIsLoading] = useState(false);

  const handlePrimaryButton = () => {
    console.log('Primary Button Pressed!');
  };

  const handleSecondaryButton = () => {
    console.log('Secondary Button Pressed!');
  };

  const handleLoadingButton = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      console.log('Action completed!');
    }, 2000);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>CustomButtonDemoScreen</Text>
      {/* Primary Button */}
      <CustomButton
        label="Let's get started"
        onPress={handlePrimaryButton}
      />
      {/* Secondary Button */}
      <CustomButton
        label="Cancel"
        onPress={handleSecondaryButton}
        type="secondary"
      />
      {/* Loading Button */}
      <CustomButton
        label={isLoading ? 'Loading...' : 'Submit'}
        onPress={handleLoadingButton}
        loading={isLoading}
        type="primary"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 20,
    marginBottom: 15,
  },
  title: {
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 18,
    marginBottom: 20,
    color: 'red',
  },
});

export default CustomButtonDemoScreen;
