import React from 'react';
import { Button } from 'react-native-paper';
import { StyleSheet } from 'react-native';

interface CustomButtonProps {
  label: string;
  onPress: () => void;
  type?: 'primary' | 'secondary';
  loading?: boolean;
}

const CustomButton: React.FC<CustomButtonProps> = ({ label, onPress, type = 'primary', loading = false }) => {
  const isPrimary = type === 'primary';

  return (
    <Button
      mode={isPrimary ? 'contained' : 'outlined'}
      onPress={onPress}
      style={[styles.button, isPrimary ? styles.primaryButton : styles.secondaryButton]}
      labelStyle={[styles.label, isPrimary ? styles.primaryLabel : styles.secondaryLabel]}
      loading={loading}
      disabled={loading}
    >
      {label}
    </Button>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: 15,
    paddingVertical: 10,
    height: 61,
  },
  primaryButton: {
    backgroundColor: '#BC6C25',
  },
  secondaryButton: {
    backgroundColor: 'transparent',
    borderWidth: 0,
    borderColor: 'transparent',
  },
  label: {
    fontSize: 20,
  },
  primaryLabel: {
    color: '#F3F3F3',
  },
  secondaryLabel: {
    fontSize: 15,
    color: "#202020",
    fontWeight: "300",
    lineHeight: 26,
    textAlign: "center",
  },
});

export default CustomButton;
