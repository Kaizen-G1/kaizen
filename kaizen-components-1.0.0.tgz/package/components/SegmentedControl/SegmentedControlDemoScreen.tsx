import React from 'react'
import { StyleSheet, View, Text } from "react-native";

// Component
import SegmentedControl from './SegmentedControl';

export const SegmentedControlDemoScreen = () => {

  const OPTIONS: string[] = ['All', 'Female', 'Male'];

  const handleSegmentChange = (selected: string) => {
    console.log(`Selected: ${selected}`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>SegmentedControlDemoScreen</Text>
      <SegmentedControl options={OPTIONS} onChange={handleSegmentChange} />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 20,
    marginBottom: 15,
  },
  title: {
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 18,
    marginBottom: 10,
    color: 'red',
  }
});
