import React, { useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Dimensions } from 'react-native';

type SegmentedControlProps = {
  options: string[];
  onChange: (selected: string) => void;
};

const SegmentedControl: React.FC<SegmentedControlProps> = ({ options, onChange }) => {
  const [selected, setSelected] = useState<string>(options[0]); // Selecting the first option by default

  const handlePress = (option: string) => {
    setSelected(option);
    onChange(option);
  };

  return (
    <View style={styles.container}>
      {options.map((option) => (
        <TouchableOpacity
          key={option}
          style={[
            styles.button,
            selected === option && styles.activeButton, // Setting active style to the button tapped
          ]}
          onPress={() => handlePress(option)}
        >
          <Text style={[styles.text, selected === option && styles.activeText]}>
            {option}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 7, // Space between buttons
    width: '100%',
  },
  button: {
    flex: 1, // All buttons have the same width
    backgroundColor: '#F9F9F9', // Inactive color
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 9,
    height: 36,
  },
  activeButton: {
    backgroundColor: '#753742', // Active color
  },
  text: {
    color: '#000', // Inactive text color
    fontSize: 16,
  },
  activeText: {
    color: '#FFFFFF', // Active text color
    fontFamily: 'Raleway',
  },
});

export default SegmentedControl;
