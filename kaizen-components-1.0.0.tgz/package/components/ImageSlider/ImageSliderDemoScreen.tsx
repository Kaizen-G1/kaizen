import React from 'react'
import { StyleSheet, View, Text, Alert, Dimensions } from 'react-native';

// Component
import ImageSlider from './ImageSlider';

// Mock Data
const CAROUSEL_IMAGES = [
  {
    id: '100',
    imageUrl: 'https://m.media-amazon.com/images/I/81VBi2RDh6L._SL500_.jpg',
  },
  {
    id: '200',
    imageUrl: 'https://cdn.magicdecor.in/com/2024/08/29110555/Drona-Mountain-Lake-House-Sunrise-Scenery-Wallpaper-Mural-710x450.jpg',
  },
  {
    id: '300',
    imageUrl: 'https://images3.alphacoders.com/133/1332803.png',
  },
];

const MARGIN_HORIZONTAL = 14;

export const ImageSliderDemoScreen = () => {
  const sliderWidth = Dimensions.get('window').width - MARGIN_HORIZONTAL * 2;
  
  const handleImagePress = (id: string) => {
    console.log(`Selected image ID: ${id}`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>ImageSliderDemoScreen</Text>
      <ImageSlider
        data={CAROUSEL_IMAGES}
        handleImagePress={handleImagePress}
        sliderWidth={sliderWidth}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginHorizontal: MARGIN_HORIZONTAL,
    marginBottom: 15,
  },
  title: {
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 18,
    marginBottom: 10,
    color: 'red',
  },
});
