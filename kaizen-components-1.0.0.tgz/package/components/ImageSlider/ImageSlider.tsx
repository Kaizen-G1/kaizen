import React, { useRef, useState } from "react";
import {
  View,
  ScrollView,
  StyleSheet,
  Image,
  TouchableOpacity,
  NativeSyntheticEvent,
  NativeScrollEvent,
} from "react-native";

type ImageSliderProps = {
  data: {
    id: string;
    imageUrl: string;
  }[];
  handleImagePress: (id: string) => void;
  sliderWidth: number;
  gap?: number;
};

const ImageSlider = ({ data, handleImagePress, sliderWidth, gap = 10 }: ImageSliderProps) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const scrollViewRef = useRef<ScrollView>(null);
  const cardWidth = sliderWidth - gap;

  const handleScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const currentIndex = Math.round(scrollPosition / sliderWidth);
    setActiveIndex(currentIndex);
  };

  const scrollToIndex = (index: number) => {
    if (scrollViewRef.current) {
      scrollViewRef.current.scrollTo({
        x: index * sliderWidth,
        animated: true,
      });
    }
  };

  return (
    <View style={[styles.container, { width: sliderWidth }]}>
      <ScrollView
        ref={scrollViewRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
      >
        {data.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={[styles.card, { width: cardWidth, marginHorizontal: gap / 2 }]}
            onPress={() => handleImagePress(item.id)}
          >
            <Image source={{ uri: item.imageUrl }} style={styles.image} />
          </TouchableOpacity>
        ))}
      </ScrollView>
      <View style={styles.pagination}>
        {data.map((_, index) => (
          <TouchableOpacity
            key={index}
            style={[
              styles.dot,
              activeIndex === index && styles.activeDot,
            ]}
            onPress={() => scrollToIndex(index)}
          />
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
  },
  card: {
    alignItems: 'center',
  },
  image: {
    width: '100%',
    height: 160,
    borderRadius: 18,
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
  },
  dot: {
    backgroundColor: '#D8BD8A',
    width: 10,
    height: 10,
    borderRadius: 5,
    marginHorizontal: 4,
  },
  activeDot: {
    backgroundColor: "#BC6C25",
    width: 40,
    height: 10,
    borderRadius: 5,
  },
});

export default ImageSlider;
