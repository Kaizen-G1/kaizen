import React from 'react';
import { StyleSheet, Image, TouchableOpacity, View, Dimensions } from 'react-native';

type CircleItemProps = {
  image: string;
  onPress: () => void;
};

const CircleItem: React.FC<CircleItemProps> = ({ image, onPress }) => {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.outerCircle}>
        <View style={styles.innerCircle}>
          <Image source={{ uri: image }} style={styles.image} />
        </View>
      </View>
    </TouchableOpacity>
  );
};

const CIRCLE_SIZE = Math.min(Dimensions.get('window').width / 7.5, 100); // Dynamic size based on the screen width
const BORDER_WIDTH = 5; // Width of the white border

const styles = StyleSheet.create({
  container: {
    marginHorizontal: CIRCLE_SIZE / 10, // Setting the margin proportional to the size of the circle
    height: CIRCLE_SIZE + 20,
  },
  outerCircle: {
    width: CIRCLE_SIZE + BORDER_WIDTH * 2,
    height: CIRCLE_SIZE + BORDER_WIDTH * 2,
    borderRadius: (CIRCLE_SIZE + BORDER_WIDTH * 2) / 2,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 5,
    elevation: 3,
  },
  innerCircle: {
    width: CIRCLE_SIZE,
    height: CIRCLE_SIZE,
    borderRadius: CIRCLE_SIZE / 2,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: '100%',
  },
});

export default CircleItem;
