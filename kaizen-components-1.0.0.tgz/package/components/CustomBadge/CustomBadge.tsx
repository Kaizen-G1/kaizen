import React from 'react';
import { StyleSheet } from 'react-native';
import { Badge } from 'react-native-paper';

type CustomBadgeProps = {
  text: string;
};

const CustomBadge: React.FC<CustomBadgeProps> = ({
  text,
}) => {
  return (
    <Badge style={styles.badge}>
      {text}
    </Badge>
  );
};

const styles = StyleSheet.create({
  badge: {
    backgroundColor: '#753742BF',
    borderRadius: 6,
    paddingHorizontal: 10,
    fontWeight: 'bold',
    fontSize: 12,
  }
});

export default CustomBadge;
