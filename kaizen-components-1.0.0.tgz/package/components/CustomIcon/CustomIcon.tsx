import React from 'react';
import { IconButton } from 'react-native-paper';

interface CustomIconProps {
  type?: "circle" | "square";
  icon: string;
  size?: number;
  iconColor?: string;
  backgroundColor?: string;
}

const CustomIcon: React.FC<CustomIconProps> = ({
  icon,
  type = "circle",
  size = 16,
  iconColor = "white",
  backgroundColor = "#753742",
}) => {

  let borderRadius;
  switch (type) {
    case "circle":
      borderRadius = 23;
      break;
    case "square":
      borderRadius = 7;
      break;
    default:
      borderRadius = 0;
  }

  return (
    <IconButton
      icon={icon}
      size={size}
      style={[{ backgroundColor, borderRadius }]}
      iconColor={iconColor}
    />
  );
};


export default CustomIcon;