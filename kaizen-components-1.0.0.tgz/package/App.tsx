import React from 'react';
import { ScrollView } from 'react-native';
import { Provider as PaperProvider } from 'react-native-paper';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

// Demo Screens
import { ImageSliderDemoScreen } from './components/ImageSlider/ImageSliderDemoScreen';
import { SegmentedControlDemoScreen } from './components/SegmentedControl/SegmentedControlDemoScreen';
import { CustomButtonDemoScreen } from './components/CustomButton/CustomButtonDemoScreen';
import { CircleListDemoScreen } from './components/CircleList/CircleListDemoScreen';
import { CategoryListDemoScreen } from './components/CategoryList/CategoryListDemoScreen';

export default function App() {

  return (
    <>
      <SafeAreaProvider>
        <PaperProvider>
          <SafeAreaView>
            <ScrollView>
              {/* Demo Screens */}
              <ImageSliderDemoScreen />
              <SegmentedControlDemoScreen />
              <CustomButtonDemoScreen />
              <CircleListDemoScreen />
              <CategoryListDemoScreen />
            </ScrollView>
          </SafeAreaView>
        </PaperProvider>
      </SafeAreaProvider>
    </>
  );
}
